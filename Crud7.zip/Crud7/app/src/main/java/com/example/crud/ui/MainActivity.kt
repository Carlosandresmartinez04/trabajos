package com.example.crud.ui

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.crud.data.Student
import com.example.crud.databinding.ActivityMainBinding
import com.example.crud.viewmodel.StudentViewModel
import android.app.AlertDialog
import android.view.LayoutInflater
import android.widget.EditText
import com.example.crud.databinding.DialogAddStudentBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: StudentViewModel by viewModels()
    private val adapter = StudentAdapter(
        onEdit = { showEditDialog(it) },
        onDelete = { viewModel.delete(it) }
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter

        viewModel.students.observe(this, Observer {
            adapter.submitList(it)
        })

        binding.fabAdd.setOnClickListener {
            showAddDialog()
        }
    }

    private fun showAddDialog() {
        val dialogBinding = DialogAddStudentBinding.inflate(LayoutInflater.from(this))
        AlertDialog.Builder(this)
            .setTitle("Agregar Estudiante")
            .setView(dialogBinding.root)
            .setPositiveButton("Guardar") { _, _ ->
                val name = dialogBinding.etName.text.toString()
                val age = dialogBinding.etAge.text.toString().toIntOrNull() ?: 0
                viewModel.insert(Student(name = name, age = age))
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showEditDialog(student: Student) {
        val dialogBinding = DialogAddStudentBinding.inflate(LayoutInflater.from(this))
        dialogBinding.etName.setText(student.name)
        dialogBinding.etAge.setText(student.age.toString())

        AlertDialog.Builder(this)
            .setTitle("Editar Estudiante")
            .setView(dialogBinding.root)
            .setPositiveButton("Actualizar") { _, _ ->
                val name = dialogBinding.etName.text.toString()
                val age = dialogBinding.etAge.text.toString().toIntOrNull() ?: 0
                viewModel.update(student.copy(name = name, age = age))
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
