package com.example.crud.repository

import com.example.crud.data.Student
import com.example.crud.data.StudentDao

class StudentRepository(private val studentDao: StudentDao) {
    val students = studentDao.getAllStudents()

    suspend fun insert(student: Student) = studentDao.insertStudent(student)
    suspend fun update(student: Student) = studentDao.updateStudent(student)
    suspend fun delete(student: Student) = studentDao.deleteStudent(student)
}
